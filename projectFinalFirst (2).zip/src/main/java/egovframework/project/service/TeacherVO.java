package egovframework.project.service;

public class TeacherVO {
	private String teacher_id;
	private String teacher_pwd;
	private String teacher_nm;
	private String teacher_cttpc;
	private int teacher_grade;
	private int teacher_clas;

	public String getTeacher_id() {
		return teacher_id;
	}

	public void setTeacher_id(String teacher_id) {
		this.teacher_id = teacher_id;
	}

	public String getTeacher_pwd() {
		return teacher_pwd;
	}

	public void setTeacher_pwd(String teacher_pwd) {
		this.teacher_pwd = teacher_pwd;
	}

	public String getTeacher_nm() {
		return teacher_nm;
	}

	public void setTeacher_nm(String teacher_nm) {
		this.teacher_nm = teacher_nm;
	}

	public String getTeacher_cttpc() {
		return teacher_cttpc;
	}

	public void setTeacher_cttpc(String teacher_cttpc) {
		this.teacher_cttpc = teacher_cttpc;
	}

	public int getTeacher_grade() {
		return teacher_grade;
	}

	public void setTeacher_grade(int teacher_grade) {
		this.teacher_grade = teacher_grade;
	}

	public int getTeacher_clas() {
		return teacher_clas;
	}

	public void setTeacher_clas(int teacher_clas) {
		this.teacher_clas = teacher_clas;
	}

}
