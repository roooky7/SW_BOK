package egovframework.project.service;

public class S_ParentsVO {
	private String s_parents_id;
	private String s_parents_pwd;
	private String s_parents_nm;
	private String s_parents_cttpc;
	private String rel;
	private String chldren_nm;
	private String chldren_schl;
	private int chldren_grade;
	private int chldren_clas;
	private String chldren_sexdstn;
	private String chldren_brdt;

	public String getS_parents_id() {
		return s_parents_id;
	}

	public void setS_parents_id(String s_parents_id) {
		this.s_parents_id = s_parents_id;
	}

	public String getS_parents_pwd() {
		return s_parents_pwd;
	}

	public void setS_parents_pwd(String s_parents_pwd) {
		this.s_parents_pwd = s_parents_pwd;
	}

	public String getS_parents_nm() {
		return s_parents_nm;
	}

	public void setS_parents_nm(String s_parents_nm) {
		this.s_parents_nm = s_parents_nm;
	}

	public String getS_parents_cttpc() {
		return s_parents_cttpc;
	}

	public void setS_parents_cttpc(String s_parents_cttpc) {
		this.s_parents_cttpc = s_parents_cttpc;
	}

	public String getRel() {
		return rel;
	}

	public void setRel(String rel) {
		this.rel = rel;
	}

	public String getChldren_nm() {
		return chldren_nm;
	}

	public void setChldren_nm(String chldren_nm) {
		this.chldren_nm = chldren_nm;
	}

	public String getChldren_schl() {
		return chldren_schl;
	}

	public void setChldren_schl(String chldren_schl) {
		this.chldren_schl = chldren_schl;
	}

	public int getChldren_grade() {
		return chldren_grade;
	}

	public void setChldren_grade(int chldren_grade) {
		this.chldren_grade = chldren_grade;
	}

	public int getChldren_clas() {
		return chldren_clas;
	}

	public void setChldren_clas(int chldren_clas) {
		this.chldren_clas = chldren_clas;
	}

	public String getChldren_sexdstn() {
		return chldren_sexdstn;
	}

	public void setChldren_sexdstn(String chldren_sexdstn) {
		this.chldren_sexdstn = chldren_sexdstn;
	}

	public String getChldren_brdt() {
		return chldren_brdt;
	}

	public void setChldren_brdt(String chldren_brdt) {
		this.chldren_brdt = chldren_brdt;
	}

}
